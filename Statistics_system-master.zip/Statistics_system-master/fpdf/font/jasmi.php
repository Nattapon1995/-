<?php
$type='Type1';
$name='JasmineUPC-Italic';
$desc=array('Ascent'=>481,'Descent'=>-132,'CapHeight'=>454,'Flags'=>96,'FontBBox'=>'[-325 -185 882 748]','ItalicAngle'=>-9.9,'StemV'=>70);
$up=-32;
$ut=5;
$cw=array(
	chr(0)=>600,chr(1)=>600,chr(2)=>600,chr(3)=>600,chr(4)=>600,chr(5)=>600,chr(6)=>600,chr(7)=>600,chr(8)=>600,chr(9)=>600,chr(10)=>600,chr(11)=>600,chr(12)=>600,chr(13)=>600,chr(14)=>600,chr(15)=>600,chr(16)=>600,chr(17)=>600,chr(18)=>600,chr(19)=>600,chr(20)=>600,chr(21)=>600,
	chr(22)=>600,chr(23)=>600,chr(24)=>600,chr(25)=>600,chr(26)=>600,chr(27)=>600,chr(28)=>600,chr(29)=>600,chr(30)=>600,chr(31)=>600,' '=>222,'!'=>262,'"'=>265,'#'=>523,'$'=>474,'%'=>687,'&'=>496,'\''=>174,'('=>249,')'=>249,'*'=>327,'+'=>365,
	','=>155,'-'=>365,'.'=>155,'/'=>373,'0'=>457,'1'=>457,'2'=>457,'3'=>457,'4'=>457,'5'=>457,'6'=>457,'7'=>457,'8'=>457,'9'=>457,':'=>190,';'=>190,'<'=>354,'='=>390,'>'=>365,'?'=>389,'@'=>508,'A'=>446,
	'B'=>422,'C'=>446,'D'=>459,'E'=>372,'F'=>347,'G'=>471,'H'=>496,'I'=>161,'J'=>298,'K'=>434,'L'=>372,'M'=>533,'N'=>459,'O'=>496,'P'=>384,'Q'=>496,'R'=>422,'S'=>372,'T'=>397,'U'=>471,'V'=>434,'W'=>583,
	'X'=>434,'Y'=>434,'Z'=>360,'['=>149,'\\'=>372,']'=>149,'^'=>409,'_'=>310,'`'=>198,'a'=>310,'b'=>322,'c'=>285,'d'=>322,'e'=>310,'f'=>186,'g'=>322,'h'=>347,'i'=>149,'j'=>136,'k'=>310,'l'=>136,'m'=>521,
	'n'=>347,'o'=>347,'p'=>360,'q'=>322,'r'=>223,'s'=>248,'t'=>186,'u'=>322,'v'=>285,'w'=>446,'x'=>310,'y'=>298,'z'=>260,'{'=>186,'|'=>409,'}'=>186,'~'=>409,chr(127)=>600,chr(128)=>600,chr(129)=>600,chr(130)=>600,chr(131)=>600,
	chr(132)=>600,chr(133)=>600,chr(134)=>600,chr(135)=>600,chr(136)=>600,chr(137)=>600,chr(138)=>600,chr(139)=>600,chr(140)=>600,chr(141)=>600,chr(142)=>600,chr(143)=>600,chr(144)=>600,chr(145)=>600,chr(146)=>600,chr(147)=>600,chr(148)=>600,chr(149)=>600,chr(150)=>600,chr(151)=>600,chr(152)=>600,chr(153)=>600,
	chr(154)=>600,chr(155)=>600,chr(156)=>600,chr(157)=>600,chr(158)=>600,chr(159)=>600,chr(160)=>222,chr(161)=>443,chr(162)=>391,chr(163)=>404,chr(164)=>447,chr(165)=>452,chr(166)=>454,chr(167)=>375,chr(168)=>392,chr(169)=>421,chr(170)=>383,chr(171)=>399,chr(172)=>649,chr(173)=>664,chr(174)=>452,chr(175)=>459,
	chr(176)=>409,chr(177)=>478,chr(178)=>664,chr(179)=>667,chr(180)=>455,chr(181)=>453,chr(182)=>447,chr(183)=>455,chr(184)=>432,chr(185)=>451,chr(186)=>464,chr(187)=>464,chr(188)=>458,chr(189)=>458,chr(190)=>500,chr(191)=>500,chr(192)=>454,chr(193)=>459,chr(194)=>438,chr(195)=>406,chr(196)=>443,chr(197)=>429,
	chr(198)=>453,chr(199)=>396,chr(200)=>443,chr(201)=>459,chr(202)=>430,chr(203)=>462,chr(204)=>489,chr(205)=>419,chr(206)=>420,chr(207)=>412,chr(208)=>263,chr(209)=>0,chr(210)=>335,chr(211)=>340,chr(212)=>0,chr(213)=>0,chr(214)=>0,chr(215)=>0,chr(216)=>0,chr(217)=>0,chr(218)=>0,chr(219)=>600,
	chr(220)=>600,chr(221)=>600,chr(222)=>600,chr(223)=>449,chr(224)=>185,chr(225)=>352,chr(226)=>180,chr(227)=>219,chr(228)=>212,chr(229)=>335,chr(230)=>539,chr(231)=>0,chr(232)=>0,chr(233)=>0,chr(234)=>0,chr(235)=>0,chr(236)=>0,chr(237)=>0,chr(238)=>0,chr(239)=>510,chr(240)=>443,chr(241)=>422,
	chr(242)=>462,chr(243)=>417,chr(244)=>399,chr(245)=>389,chr(246)=>393,chr(247)=>523,chr(248)=>434,chr(249)=>447,chr(250)=>515,chr(251)=>896,chr(252)=>600,chr(253)=>600,chr(254)=>600,chr(255)=>600);
$enc='iso-8859-11';
$diff='128 /.notdef 130 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 142 /.notdef 145 /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef /.notdef 158 /.notdef /.notdef 161 /kokaithai /khokhaithai /khokhuatthai /khokhwaithai /khokhonthai /khorakhangthai /ngonguthai /chochanthai /chochingthai /chochangthai /sosothai /chochoethai /yoyingthai /dochadathai /topatakthai /thothanthai /thonangmonthothai /thophuthaothai /nonenthai /dodekthai /totaothai /thothungthai /thothahanthai /thothongthai /nonuthai /bobaimaithai /poplathai /phophungthai /fofathai /phophanthai /fofanthai /phosamphaothai /momathai /yoyakthai /roruathai /ruthai /lolingthai /luthai /wowaenthai /sosalathai /sorusithai /sosuathai /hohipthai /lochulathai /oangthai /honokhukthai /paiyannoithai /saraathai /maihanakatthai /saraaathai /saraamthai /saraithai /saraiithai /sarauethai /saraueethai /sarauthai /sarauuthai /phinthuthai /.notdef /.notdef /.notdef /.notdef /bahtthai /saraethai /saraaethai /saraothai /saraaimaimuanthai /saraaimaimalaithai /lakkhangyaothai /maiyamokthai /maitaikhuthai /maiekthai /maithothai /maitrithai /maichattawathai /thanthakhatthai /nikhahitthai /yamakkanthai /fongmanthai /zerothai /onethai /twothai /threethai /fourthai /fivethai /sixthai /seventhai /eightthai /ninethai /angkhankhuthai /khomutthai /.notdef /.notdef /.notdef /.notdef';
$file='jasmi.z';
$size1=5678;
$size2=37898;
?>
